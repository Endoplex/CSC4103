Justin Nguyen

89-543-7433

jngu178@lsu.edu

Compile the program using g++ 
type in "g++ -pthread -o sudoku-validator main.cpp"
run the program using the command: ./sudoku-validator sudoku.txt results.txt

![image](https://user-images.githubusercontent.com/76065821/220488596-694c3a59-9771-4fe4-a592-b33474cb59f4.png)

expected output in "results.txt":

![image](https://user-images.githubusercontent.com/76065821/220488678-72da746e-657b-43fd-9c62-87bb162ff56c.png)

expected output when inputing a bad sudoku solution:

![image](https://user-images.githubusercontent.com/76065821/220488994-87f296f2-d17a-463a-a366-dec34f5c89a0.png)

